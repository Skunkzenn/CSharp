﻿using System.Reflection;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;
using System.Text.RegularExpressions;

namespace Grupo2
{
    class AtividadeDesportiva
    {
        public static List<Ciclista> listCiclistas = new List<Ciclista>();
        public double DistanciaProva {  get; set; }
        public string TipoTerreno { get; set; }
        public string CategoriaEvento { get; set; }

        public AtividadeDesportiva(double distanciaProva, string tipoTerreno, string categoriaEvento)
        {
            DistanciaProva = distanciaProva;
            TipoTerreno = tipoTerreno;
            CategoriaEvento = categoriaEvento;
        }

        public void RegistarCiclista(Ciclista ciclista)
        {
            listCiclistas.Add(ciclista);
            Console.WriteLine($"Ciclista: {ciclista.Id}, {ciclista.Nome}, {ciclista.Equipe}");
        }


        public static void PrepararResultados()
        {
            // Ordenar a lista de ciclistas com base no tempo total
            listCiclistas = listCiclistas.OrderBy(c => c.TempoProva).ToList();

            // Exibir os resultados
            Console.WriteLine("Resultados da Prova:");
            foreach (var ciclista in listCiclistas)
            {
                Console.WriteLine($"{ciclista.Nome} - Tempo Total: {ciclista.TempoProva}");
            }
        }

        public override string ToString()
        {
            return $"Distancia Prova: {DistanciaProva}\nTipo de Terreno: {TipoTerreno}\nCategoria do Evento: {CategoriaEvento}";
        }
        public static void GuardarFicheiro(string nomeFicheiro)
        {
            try
            {
                IFormatter formatter = new BinaryFormatter();
                using (Stream stream = new FileStream(nomeFicheiro, FileMode.Create, FileAccess.Write))
                {
                    formatter.Serialize(stream, listCiclistas);
                    Console.WriteLine("Dados guardados com sucesso!");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao guardar dados: {ex.Message}");
            }
        }

        public static void CarregarDeFicheiro(string nomeArquivo)
        {
            try
            {
                IFormatter formatter = new BinaryFormatter();
                using (Stream stream = new FileStream(nomeArquivo, FileMode.Open, FileAccess.Read))
                {
                    listCiclistas = (List<Ciclista>)formatter.Deserialize(stream);
                    Console.WriteLine("Dados carregados com sucesso!");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao carregar dados: {ex.Message}");
            }
        }
    }
}
