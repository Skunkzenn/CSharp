﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupo2
{
    class CiclismoEstradaProfissional : AtividadeDesportiva  {

        public CiclismoEstradaProfissional(double distanciaProva, string tipoTerreno, string categoriaEvento):base(distanciaProva, tipoTerreno, categoriaEvento) { }

            public static void OrdemPartida()
            {
                Console.WriteLine("Ordem de Partida");
                listCiclistas = listCiclistas.OrderBy(c => c.Ranking).ToList();
                foreach (var ciclista in listCiclistas)
                {
                    Console.WriteLine($"{ciclista.Nome} - Ranking: {ciclista.Ranking}");
                }
            }
    }

}
