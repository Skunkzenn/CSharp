﻿
namespace Grupo2
{
    [Serializable]

    class Ciclista : AtividadeDesportiva
    {
        

        public string Nome { get; set; }
        public string Equipe { get; set; }
        public int Idade {  get; set; }
        public string SeguroDesportivo { get; set; }
        public int Id {  get; set; }
        public int Ranking { get; set; }
        public bool Desistiu { get; set; }


        public TimeSpan TempoProva { get; set; }
        public double MediaVelocidade { get; set; }

        public Ciclista(double distanciaProva, string tipoTerreno, string categoriaEvento, string nome, string equipe, int idade, string seguroDesportivo, int id, int ranking, TimeSpan tempoProva, double mediaVelocidade):base(distanciaProva,  tipoTerreno, categoriaEvento)
        {
            Nome = nome;
            Equipe = equipe;
            Idade = idade;
            SeguroDesportivo = seguroDesportivo;
            Id = id;
            Ranking = ranking;
            TempoProva = tempoProva;
            MediaVelocidade = mediaVelocidade;
            Desistiu = false;
        }

        public void RegistrarTempoTotal(TimeSpan tempoPercurso)
        {
            TempoProva += tempoPercurso;
        }

        public static List<Ciclista> GetCiclista()
        {
            foreach (Ciclista ciclista in listCiclistas)
            {
                Console.WriteLine($"{ciclista.Nome}, {ciclista.Id}, {ciclista.Idade}, {ciclista.MediaVelocidade}");
            }

            return listCiclistas;
        }



    }
}
