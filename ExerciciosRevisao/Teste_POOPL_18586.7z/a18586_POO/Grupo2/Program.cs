﻿using Grupo2;

Ciclista ciclista1 = new Ciclista(30.00, "Terra", "Categoria A", "Victor", "RedBull", 18, "Generali", 20, 02, TimeSpan.FromMinutes(10), 15.54);
Ciclista ciclista2 = new Ciclista(30.00, "Terra", "Categoria A", "Carlos", "Magic", 18, "Generali", 20, 01, TimeSpan.FromMinutes(10), 15.54);

AtividadeDesportiva.listCiclistas.Add(ciclista1);
AtividadeDesportiva.listCiclistas.Add(ciclista2);

//ordemPartida
CiclismoEstradaProfissional.OrdemPartida();

//Regista tempo da etapa
TimeSpan tempoEtapa = TimeSpan.FromMinutes(5);
ciclista1.RegistrarTempoTotal(tempoEtapa);
ciclista2.RegistrarTempoTotal(tempoEtapa);

//prepara e exibe os resultados
AtividadeDesportiva.PrepararResultados();


//Desistência da Prova
ciclista1.Desistiu = true;

//Guarda em ficheiro
AtividadeDesportiva.GuardarFicheiro("ficheiro.txt");