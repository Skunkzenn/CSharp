﻿namespace Grupo1
{
    internal class Mamiferos : Animal
    {
        public string CorPelo { get; set; }
        public string TipoPelo { get; set; }

        public Mamiferos(string nome, int idade, double peso, string corOlhos, string corPelo, string tipoPelo) : base(nome, idade, peso, corOlhos)
        {
            CorPelo = corPelo;
            TipoPelo = tipoPelo;
        }

        public virtual void Brincam() { 
        }

        public virtual void Saltam(){

        }

        public override string ToString()
        {
            return $"{base.ToString()} + {CorPelo} + {TipoPelo}";
        }
    }
}
