﻿namespace Grupo1
{
    class Repiteis : Animal
    {
        public string TipoEscama {  get; set; }
        public string TipoCalda { get; set; }

        public Repiteis(string nome, int idade, double peso, string corOlhos, string tipoEscama, string tipoCalda):base( nome, idade,  peso, corOlhos)
        {
            TipoEscama = tipoEscama;
            TipoCalda = tipoCalda;
        }

        public void Rastejam() {
            Console.WriteLine("Escondidos entre a mata");
        }

        public void Saltam() {
            Console.WriteLine("Aranhas saltam.");
        }
    }
}
