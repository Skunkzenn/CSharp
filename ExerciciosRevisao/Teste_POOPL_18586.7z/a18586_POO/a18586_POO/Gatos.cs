﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupo1
{
    internal class Gato : Mamiferos
    {
        public Gato (string nome, int idade, double peso, string corOlhos, string corPelo, string tipoPelo) : base(nome, idade, peso, corOlhos, corPelo, tipoPelo) { 
        }

        public override void Brincam()
        {
            Console.WriteLine("Sobe às arvores");
        }

        public void Miar()
        {
            Console.WriteLine("Miau");
        }

        public override void Dormir()
        {
            Console.WriteLine("Dorme 18 horas por dia aproximadamente");
        }
    }
}
