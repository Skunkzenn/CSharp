﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupo1
{
    class Aves : Animal
    {
        public string TipoPena { get; set; }
        public string CorPena { get; set; }

        public Aves(string nome, int idade, double peso, string corOlhos, string tipoPena, string corPena):base( nome,  idade,  peso, corOlhos)
        {
            TipoPena = tipoPena;
            CorPena = corPena;
        }

        public void Voam() { 
        }

        public void PoeOvos() { 
        }

        public override void Dormir()
        {
            Console.WriteLine("Dorme no ninho");
        }

        public override string ToString()
        {
            return $"{base.ToString()} + {TipoPena} + {CorPena}";
        }
    }
}
