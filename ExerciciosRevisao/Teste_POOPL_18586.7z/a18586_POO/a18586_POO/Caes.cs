﻿namespace Grupo1
{
    class Caes : Mamiferos
    {
        public Caes(string nome, int idade, double peso, string corOlhos, string corPelo, string tipoPelo) : base(nome, idade, peso, corOlhos, corPelo, tipoPelo)
        {
        }

        public override void Brincam()
        {
            Console.WriteLine("Brinca com osso");
        }

        public void Ladrar()
        {
            Console.WriteLine("Au-au");
        }
    }
}