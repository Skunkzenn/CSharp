﻿namespace Grupo1
{
    class Animal
    {
        public static List<Animal> listAnimais = new List<Animal>();
        public string Nome { get; set; }
        public int Idade { get; set; }
        public double Peso { get; set; }
        public string CorOlhos { get; set; }
     
        public Animal(string nome, int idade, double peso, string corOlhos)
        {
            Nome = nome;
            Idade = idade;
            Peso = peso;
            CorOlhos = corOlhos;
        }
        public List<Animal> GetAnimals() { return listAnimais; }

        public void Comer()
        {
            Console.WriteLine();
        }

        public virtual void Dormir()
        {

        }

        public override string ToString()
        {
            return Nome + Idade + Peso + CorOlhos;
        }

    }

    
}
